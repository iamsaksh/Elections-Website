from django.db import models
from tastypie.resources import ModelResource
from voters.models import Voter

class VoterResource(ModelResource):
    class Meta:
        queryset = Voter.objects.all()
        resource_name = 'voters'
