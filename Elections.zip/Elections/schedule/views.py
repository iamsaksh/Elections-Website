from django.shortcuts import render
from .models import Schedule

def index(request):
    schedule = Schedule.objects.all()
    return render(request,'sch.html',{'schedule' : schedule})



