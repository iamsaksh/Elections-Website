from django.shortcuts import render
from .models import Partie


def index(request):
    parties = Partie.objects.all()
    return render(request, 'index.html', {'parties': parties})