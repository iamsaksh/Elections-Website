from django.db import models

class Partie(models.Model):
    party_name = models.CharField(max_length= 255)
    def __str__(self):
        return self.party_name
    party_symbol = models.CharField(max_length= 2083)
