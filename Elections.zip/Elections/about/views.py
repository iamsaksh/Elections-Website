from django.shortcuts import render
from .models import About
from django.shortcuts import render, get_object_or_404

def abt(request):
    about = About.objects.all()
    return render(request,'about.html',{'about' : about})

def home(request):
    return render(request,'home.html')

def detail(request,about_id):
    abt = get_object_or_404(About,id =about_id)
    return render(request, 'detail.html', {'about': abt})