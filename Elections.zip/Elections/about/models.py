from django.db import models

class About(models.Model):
    questions = models.CharField(max_length= 255)
    def __str__(self):
        return self.questions
    information = models.CharField(max_length=2083)
    def __str__(self):
        return self.information
