from django.urls import path
from . import views

urlpatterns = [
    path('about/',views.abt, name='about'),
    path('', views.home, name='home'),
    path('<int:about_id>', views.detail, name='abt' ),
]