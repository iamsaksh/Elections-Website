from django.shortcuts import render
from .models import Date

def dates(request):
    dates = Date.objects.all()
    return render(request,'dates.html',{'dates': dates})
    

