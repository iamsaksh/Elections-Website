from django.db import models
from voters.models import State, Constituencie

class Date(models.Model):
    phase = models.IntegerField()
    states = models.ForeignKey(State, on_delete=models.CASCADE)
    constituency = models.ForeignKey(Constituencie, on_delete=models.CASCADE)
    date = models.DateField()

