from django.db import models
from parties.models import Partie


class Outcome(models.Model):
    party_info = models.ForeignKey(Partie, on_delete=models.CASCADE)

class Votes(models.Model):
    name_info = models.ForeignKey('voters.Voter', on_delete=models.CASCADE)