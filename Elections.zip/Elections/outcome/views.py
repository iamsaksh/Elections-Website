from django.shortcuts import render
from .models import Outcome

def out(request):
    outcome = Outcome.objects.all()
    return render(request,'outcome.html',{'outcome' : outcome})