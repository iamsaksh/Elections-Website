from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, Http404
from .models import Voter

def index(request):
    voters = Voter.objects.all()
                                                                                    #output = ', '.join([v.name for v in voters])
    return render(request, 'voters/index.html', { 'voters' : voters })

def detail(request,voter_id):
                                                                                        #try:
    voter = get_object_or_404(Voter,id=voter_id)                                          #voter = Voter.objects.get(id=voter_id)
    return render(request, 'voters/detail.html', {'voter': voter})
                                                                                        #except Voter.DoesNotExist:

