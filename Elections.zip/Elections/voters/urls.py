from django.urls import path
from . import views

#app_name = 'voter'
urlpatterns = [
    path('',views.index, name='voter_index'),
    path('<int:voter_id>', views.detail, name='voter_detail' ),
]