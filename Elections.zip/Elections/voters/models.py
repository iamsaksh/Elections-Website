from django.db import models
from django.contrib.auth.models import User

class Gender(models.Model):
    genders = models.CharField(max_length=10)

    def __str__(self):
        return self.genders
class State(models.Model):
    state = models.CharField(max_length= 200)
    def __str__(self):
        return self.state

class Constituencie(models.Model):
    constituencies = models.CharField(max_length= 255)
    def __str__(self):
        return self.constituencies

class Voter(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE())
    name = models.CharField(max_length = 255)
    age = models.IntegerField()
    gender =models.ForeignKey(Gender, on_delete=models.CASCADE)
    constituency =models.ForeignKey(Constituencie, on_delete=models.CASCADE)
    states = models.ForeignKey(State, on_delete=models.CASCADE)
    aadhar_card_number = models.IntegerField()
    phone_number = models.IntegerField()






