from django.contrib import admin
from .models import Gender, State, Constituencie, Voter
from parties.models import Partie
from schedule.models import Schedule
from dates.models import Date
from about.models import About
from outcome.models import Outcome



class GenderAdmin(admin.ModelAdmin):
    list_display = ('id','genders')


class StatesAdmin(admin.ModelAdmin):
    list_display =('id','state')


class ConstituencyAdmin(admin.ModelAdmin):
    list_display =('id','constituencies')


class VotersAdmin(admin.ModelAdmin):
    list_display =('name','age','gender','aadhar_card_number','phone_number','states','constituency')

class PartiesAdmin(admin.ModelAdmin):
    list_display = ('id','party_name')

class ScheduleAdmin(admin.ModelAdmin):
    list_display = ('phase', 'states', 'constituency')

class DateAdmin(admin.ModelAdmin):
    list_display = ('phase','states','constituency','date')

class AboutAdmin(admin.ModelAdmin):
    list_display = ('id','questions','information')


class OutcomeAdmin(admin.ModelAdmin):
    list_display = ('party_info',)



admin.site.register(Gender, GenderAdmin)
admin.site.register(State, StatesAdmin)
admin.site.register(Constituencie, ConstituencyAdmin)
admin.site.register(Voter, VotersAdmin)
admin.site.register(Partie, PartiesAdmin)
admin.site.register(Schedule, ScheduleAdmin)
admin.site.register(Date, DateAdmin)
admin.site.register(About,AboutAdmin)
admin.site.register(Outcome, OutcomeAdmin)



